# Lua

This is the repository of Lua development code, as seen by the Lua team. It contains the full history of all commits but is mirrored irregularly. For complete information about Lua, visit [Lua.org](https://www.lua.org/).

Please **do not** send pull requests. To report issues, post a message to the [Lua mailing list](https://www.lua.org/lua-l.html).

Download official Lua releases from [Lua.org](https://www.lua.org/download.html).

windows
cmake -B build -S .
cmake --build build --config Release


liunx macOS
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release
cmake --build build
