/*
** lsproto.h - Cross-VM Read-Only Shared Table Pool
**
** Executes a Lua script in an internal master lua_State; the returned
** table (and every reachable sub-table / string) is marked with SHAREDBIT
** so no state's GC will collect or traverse it.  Other lua_States push
** the *same* Table* via luaP_querytable() - zero-copy, one physical copy.
**
** The shared table is READ-ONLY.  Writing to it is undefined behavior.
*/

#ifndef lsproto_h
#define lsproto_h

#include "lua.h"

LUA_API void   luaP_init(void);
LUA_API void   luaP_shutdown(void);

/*
** luaP_sharetable(name, filename):
**   First load: execute 'filename' in master state, mark returned table
**   shared.  Returns 0 on success, negative on error, 0 if already loaded.
**
** luaP_updatetable(name, filename):
**   Hot-reload: re-execute 'filename', replace entry.  Old table stays
**   alive (SHAREDBIT kept) so existing VM references remain valid but
**   stale.  New luaP_querytable calls return the updated version.
**   Returns 0 on success, negative on error.
**
** luaP_querytable(L, name):
**   Push the shared Table onto L's stack (zero-copy).
**   Returns 1 on success, 0 if name not found.
**
** luaP_generation(name):
**   Returns a monotonically increasing version counter (starts at 1).
**   Bumped on each luaP_updatetable.  VMs can poll this to detect stale
**   local references.  Returns 0 if name not found.
**
** luaP_sharetablecount():
**   Number of entries in the shared table pool.
*/
LUA_API int          luaP_sharetable(const char *name, const char *filename);
LUA_API int          luaP_updatetable(const char *name, const char *filename);
LUA_API int          luaP_querytable(lua_State *L, const char *name);
LUA_API unsigned int luaP_generation(const char *name);
LUA_API int          luaP_sharetablecount(void);

/* hash seed of the master state (used by ltable.c for shared table lookups) */
LUA_API unsigned int luaP_masterseed(void);

#endif
