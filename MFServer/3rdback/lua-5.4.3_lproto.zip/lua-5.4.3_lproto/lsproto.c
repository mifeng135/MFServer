/*
** lsproto.c - Cross-VM Read-Only Shared Table Pool
**
** Executes Lua scripts in a master state, marks the returned table tree
** with SHAREDBIT (see lgc.h) so every lua_State can reference the same
** physical memory without GC interference.
*/

#include "lprefix.h"

#define LUA_CORE

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifdef _MSC_VER
#define sp_strdup _strdup
#else
#define sp_strdup strdup
#endif

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "lsproto.h"

#include "lobject.h"
#include "lstate.h"
#include "lgc.h"
#include "ltable.h"

/* =====================================================================
 * Platform read-write lock
 * ===================================================================== */

#ifdef _WIN32
#include <windows.h>
static SRWLOCK g_rwlock = SRWLOCK_INIT;
#define sp_rlock()     AcquireSRWLockShared(&g_rwlock)
#define sp_runlock()   ReleaseSRWLockShared(&g_rwlock)
#define sp_wlock()     AcquireSRWLockExclusive(&g_rwlock)
#define sp_wunlock()   ReleaseSRWLockExclusive(&g_rwlock)
#else
#include <pthread.h>
static pthread_rwlock_t g_rwlock = PTHREAD_RWLOCK_INITIALIZER;
#define sp_rlock()     pthread_rwlock_rdlock(&g_rwlock)
#define sp_runlock()   pthread_rwlock_unlock(&g_rwlock)
#define sp_wlock()     pthread_rwlock_wrlock(&g_rwlock)
#define sp_wunlock()   pthread_rwlock_unlock(&g_rwlock)
#endif

/* =====================================================================
 * Shared Table Pool
 * ===================================================================== */

#define ST_BUCKETS 128

typedef struct STEntry {
    char    *name;
    int      stk_index;   /* stack index in g_master where the table lives */
    unsigned int generation; /* bumped on each update */
    struct STEntry *next;
} STEntry;

static struct {
    STEntry *buckets[ST_BUCKETS];
    int      count;
} g_stpool;

static lua_State *g_master = NULL;
static unsigned int g_master_seed = 0;

static unsigned int st_hash(const char *s) {
    unsigned int h = 0;
    for (; *s; s++) h = h * 31 + (unsigned char)*s;
    return h;
}

static STEntry *st_find(const char *name) {
    unsigned int idx = st_hash(name) % ST_BUCKETS;
    for (STEntry *e = g_stpool.buckets[idx]; e; e = e->next)
        if (strcmp(e->name, name) == 0) return e;
    return NULL;
}

/* =====================================================================
 * Recursive SHAREDBIT marking
 * ===================================================================== */

static void sp_mark_shared_obj(GCObject *o);

static void sp_mark_shared_value(const TValue *v) {
    if (!iscollectable(v)) return;
    GCObject *o = gcvalue(v);
    if (isshared(o)) return;
    sp_mark_shared_obj(o);
}

static void sp_mark_shared_obj(GCObject *o) {
    if (isshared(o)) return;
    makeshared(o);
    switch (o->tt) {
        case LUA_VSHRSTR:
        case LUA_VLNGSTR:
            break;
        case LUA_VTABLE: {
            Table *t = gco2t(o);
            if (t->metatable)
                sp_mark_shared_obj(obj2gco(t->metatable));
            unsigned int asize = luaH_realasize(t);
            for (unsigned int i = 0; i < asize; i++)
                sp_mark_shared_value(&t->array[i]);
            unsigned int nsize = allocsizenode(t);
            for (unsigned int i = 0; i < nsize; i++) {
                Node *n = gnode(t, i);
                if (!isempty(gval(n))) {
                    if (keyiscollectable(n))
                        sp_mark_shared_obj(gckey(n));
                    sp_mark_shared_value(gval(n));
                }
            }
            break;
        }
        default:
            break;
    }
}

/* =====================================================================
 * Public API
 * ===================================================================== */

LUA_API void luaP_init(void) {
    memset(&g_stpool, 0, sizeof(g_stpool));
    g_master = luaL_newstate();
    if (g_master) {
        g_master_seed = G(g_master)->seed;
        luaL_openlibs(g_master);
    }
}

LUA_API unsigned int luaP_masterseed(void) {
    return g_master_seed;
}

LUA_API void luaP_shutdown(void) {
    sp_wlock();
    /*
    ** Clear SHAREDBIT on all shared objects so g_master's GC can free them
    ** normally when lua_close is called below.
    */
    if (g_master) {
        global_State *g = G(g_master);
        GCObject *o;
        for (o = g->allgc; o != NULL; o = o->next)
            if (isshared(o)) resetbit(o->marked, SHAREDBIT);
        for (o = g->fixedgc; o != NULL; o = o->next)
            if (isshared(o)) resetbit(o->marked, SHAREDBIT);
    }
    for (int i = 0; i < ST_BUCKETS; i++) {
        STEntry *e = g_stpool.buckets[i];
        while (e) {
            STEntry *nx = e->next;
            free(e->name);
            free(e);
            e = nx;
        }
        g_stpool.buckets[i] = NULL;
    }
    g_stpool.count = 0;
    sp_wunlock();
    if (g_master) { lua_close(g_master); g_master = NULL; }
}

/*
** Load a Lua file in g_master, expect a table on top, mark it shared.
** Returns the new stack index, or -1 on error.  Caller holds sp_wlock.
** GC is stopped before call and restarted by caller.
*/
static int st_load_and_mark(const char *name, const char *filename) {
    if (luaL_dofile(g_master, filename) != LUA_OK) {
        fprintf(stderr, "[lsproto] sharetable '%s': %s\n",
                name, lua_tostring(g_master, -1));
        lua_pop(g_master, 1);
        return -1;
    }
    if (!lua_istable(g_master, -1)) {
        fprintf(stderr, "[lsproto] sharetable '%s': script must return a table\n", name);
        lua_pop(g_master, 1);
        return -1;
    }
    Table *t = (Table *)lua_topointer(g_master, -1);
    sp_mark_shared_obj(obj2gco(t));
    return lua_gettop(g_master);
}

LUA_API int luaP_sharetable(const char *name, const char *filename) {
    if (!g_master || !name || !filename) return -1;

    sp_wlock();
    if (st_find(name)) { sp_wunlock(); return 0; }

    lua_gc(g_master, LUA_GCSTOP, 0);
    int stk = st_load_and_mark(name, filename);
    lua_gc(g_master, LUA_GCRESTART, 0);
    if (stk < 0) { sp_wunlock(); return -2; }

    unsigned int idx = st_hash(name) % ST_BUCKETS;
    STEntry *entry = (STEntry *)malloc(sizeof(STEntry));
    entry->name       = sp_strdup(name);
    entry->stk_index  = stk;
    entry->generation = 1;
    entry->next       = g_stpool.buckets[idx];
    g_stpool.buckets[idx] = entry;
    g_stpool.count++;

    sp_wunlock();
    return 0;
}

LUA_API int luaP_updatetable(const char *name, const char *filename) {
    if (!g_master || !name || !filename) return -1;

    sp_wlock();
    STEntry *e = st_find(name);
    if (!e) {
        sp_wunlock();
        return -1;
    }

    lua_gc(g_master, LUA_GCSTOP, 0);

    /*
    ** Old table stays on g_master's stack with SHAREDBIT set.
    ** VMs that still hold a pointer to it keep working (stale but safe).
    ** It will be freed only at luaP_shutdown when SHAREDBIT is cleared.
    */
    int stk = st_load_and_mark(name, filename);
    lua_gc(g_master, LUA_GCRESTART, 0);
    if (stk < 0) { sp_wunlock(); return -2; }

    e->stk_index = stk;
    e->generation++;

    sp_wunlock();
    return 0;
}

LUA_API unsigned int luaP_generation(const char *name) {
    sp_rlock();
    STEntry *e = st_find(name);
    unsigned int gen = e ? e->generation : 0;
    sp_runlock();
    return gen;
}

LUA_API int luaP_querytable(lua_State *L, const char *name) {
    sp_rlock();
    STEntry *e = st_find(name);
    if (!e) { sp_runlock(); return 0; }

    const void *p = lua_topointer(g_master, e->stk_index);
    if (!p) { sp_runlock(); return 0; }
    sp_runlock();

    lua_pushsharedtable(L, (void *)p);
    return 1;
}

LUA_API int luaP_sharetablecount(void) {
    sp_rlock();
    int n = g_stpool.count;
    sp_runlock();
    return n;
}
